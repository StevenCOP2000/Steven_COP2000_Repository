//Steven Torres-Romero; September 16th 2018 COP2000 T-6:35
//Description: Homework 1 - Malachi's Pie Shop
//The following program will show you how many of each ingredient you will need to make the number of pies you wish to make

#include<iostream>
#include<iomanip>

using namespace std;

int main()
{
	const float FLOUR = 15.00;//cups
	const float SUGAR = 8.00;//tablespoons
	const float SALT = 3.00;//tablespoons
	const float BUTTER = 5.23;//cups
	const float EGGS = 6.00;//large eggs

	float amount_of_pies;
	float flour_needed;
	float sugar_needed;
	float salt_needed;
	float butter_needed;
	float eggs_needed;

	cout << "How many pies do you wish to make? \n> ";
	
	cin >> amount_of_pies;

	flour_needed = FLOUR / 6.00;
	sugar_needed = SUGAR / 6.00;
	salt_needed = SALT / 6.00;
	butter_needed = BUTTER / 6.00;
	eggs_needed = EGGS / 6.00;


	flour_needed *= amount_of_pies;
	sugar_needed *= amount_of_pies;
	salt_needed *= amount_of_pies;
	butter_needed *= amount_of_pies;
	eggs_needed *= amount_of_pies;

	cout << setprecision(2) << fixed;

	cout << "\n";
	cout << "Malachi's Pie Shop - Pie Crust Recipe \n";
	cout << "------------------------------------- \n";
	cout << "You wish to make " << amount_of_pies << " Pies. \n" << endl;

	cout << "Flour	" << flour_needed << " cups \n";
	cout << "Sugar	" << sugar_needed << " tablespoons \n";
	cout << "Salt	" << salt_needed << " tablespoons \n";
	cout << "Butter	" << butter_needed << " cups \n";
	cout << "Eggs	" << eggs_needed << " large eggs \n";



	return 0;
}