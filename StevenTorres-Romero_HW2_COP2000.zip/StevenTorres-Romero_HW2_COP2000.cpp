// Steven Torres-Romero COP_2000 HW2 10/1/2018
// This program is used to calculate the area of a room depending on the shape of the room.
#include <iostream> 
#include <iomanip>
using namespace std;

int main()

{

int user_menu_input = 0;
float room_length = 0;
float room_width = 0;
float room_radius = 0;
float pi = 3.141592;

	cout << setprecision(2) << fixed;

	cout << "Haverly's Room Calculator" << endl;
	cout << "===== MENU ======" << endl;
	cout << "1. Square Room" << endl;
	cout << "2. Rectangular Room" << endl;
	cout << "3. Round Room" << endl;
	cout << "4. Quit" << endl;
	cout << "Please enter a menu item (1-4) > ";
	cin >> user_menu_input;

	while (user_menu_input <= 0)
	{
		cout << "Invalid number has been inputted, please enter a number between 1 and 4. > ";
		cin >> user_menu_input;
	}
	while (user_menu_input >= 5)
	{
		cout << "Invalid number has been inputted, please enter a number between 1 and 4. > ";
		cin >> user_menu_input;
	}

	switch (user_menu_input)

	{

	case 1:

		cout << "\nSquare Room\n"
			"Please enter the length room in square feet. > ";
		cin >> room_length;

		while (room_length <= 0)

		{

			cout << "Invalid number has been inputted, please enter a positive number. > ";
			cin >> room_length;

		}

		cout << "Carpet needed is " << (room_length * room_length) << " in square feet. " << endl;

	break;

	}

	switch (user_menu_input)

	{

	case 2:
		
		cout << "\nRectangular Room\n";
		cout << "Please enter the length room in square feet. > ";
		cin >> room_length;
		
		while (room_length <= 0)
		
		{
			cout << "Invalid number has been inputted, please enter a positive number > ";
			cin >> room_length;

			
		}
		
		cout << "Please enter the width of the room in square feet. > ";
		cin >> room_width;

		while (room_width <= 0)
		{
			cout << "Invalid number has been inputted, please enter a positive number. > ";
			cin >> room_width;
		}
		
		cout << "Carpet needed is " << (room_length * room_width) << " in square feet. " << endl;

	break;
	}

	switch (user_menu_input)
	{
	
	case 3:
		cout << "\nRound Room\n"
			"Please enter the radius of the room in square feet. > ";
		cin >> room_radius;

		while (room_radius <= 0)
		{
			cout << "Invalid number has been inputted, please enter a positive number. > ";
			cin >> room_radius;

		}
		room_radius *= room_radius;
		cout << "Carpet needed is " << (pi * room_radius) << " in square feet. " << endl;
	break;
	}

	switch (user_menu_input)
	{

	case 4:
		cout << "Thank you for choosing Haverly's Room Calculator";
	break;
	}

	return 0;

}



