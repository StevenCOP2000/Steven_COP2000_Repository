//Steven Torres-Romero 11/26/2018
//COP2000 Homework 5
// This program will allow a user to play the missing number game.

#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <ctime>

using namespace std;

int beginGame(int playedBoard[]);  
void instructions();            
void displayBoard(int board[][3]); 
bool testWinner(int, int, int[]);  
									
int main()
{
	int board0[4][3] = {	{21, 3, 30},
							{43, 7, 61},
							{22, 4, 13},
							{97, NULL, 88} };

	int board1[4][3] = { {67, 13, 94,},
						 {36, 9, 81},
						 {91, 10, 55},
						 {44, NULL, 26} };

	int board2[4][3] = { {77, 14, 95,},
						 {96, 15, 87},
						 {93, 12, 75},
						 {33, NULL, 24} };

	int ansBoard[3] = { 16, 8, 6 };
	int playedBoard[3] = { NULL };
	int answer;
	int wins = 0;
	int guesses = 0;
	int boardNum;
	bool winner;

	cout << setprecision(2) << fixed << showpoint;

	instructions();

	do
	{
		boardNum = beginGame(playedBoard);
		guesses = 0;

		do
		{

			switch (boardNum)
			{

			case 0:
				displayBoard(board0);
				break;
			case 1:
				displayBoard(board1);
				break;
			case 2:
				displayBoard(board2);
				break;
			}


			cout << "Enter Guess or 0 to Exit >   ";

			cin >> answer;

			while (answer < 0)
			{
				cout << "Sorry, invalid number. Guess a digit greater than 0, or enter 0 to Exit > ";
				cin >> answer;
			}

			if (answer == 0)
			{
				cout << "Thank you for playing, have a nice day";
				return 0;
			}

			winner = testWinner(answer, boardNum, ansBoard);

			{
				if (winner)
				{
					wins += 1;
					playedBoard[boardNum] = 1;


					if (wins == 3)
					{
						cout << "*** You are the number guessing champion!! CONGRATULATIONS!! *** " << endl;
						return 0;
					}
					cout << "Do you wish to play Again? Enter 0 to Exit, or any number to continue... > \n";
					cin >> answer;

					if (answer == 0)
					{
						cout << "Thank you for playing, have a nice day";
						return 0;
					}


				}

				else
				{
					guesses += 1;
				}
			}

		} while (winner != true && guesses < 3);


		if (guesses == 3)
		{
			cout << "Sorry... You are out of guesses...\n";
			cout << "Do you wish to play again?? Enter 0 to Exit, or any number to continue... >\n";
			cin >> answer;

			if (answer == 0)
			{
				cout << "Thank you for playing, have a nice day";
				return 0;
			}
		}



	} while (wins < 3);


system("PAUSE");
return 0;
}


int beginGame(int playedBoard[])
{
	int randomNum;
	srand(time(0));

	do
	{
		
		randomNum = (rand() % (2 - 0 + 1)) + 0;
		
		if (playedBoard[randomNum] == NULL)
			return randomNum;
	}
	
	while (playedBoard[randomNum] != NULL);


}

void displayBoard(int board[][3])
{
	
	int row = 4;
	int col = 3;

	 
	for (int x = 0; x < row; x++)
	{
		for (int y = 0; y < col; y++)
		{
			if (board[x][y] == NULL)  
				cout << setw(8) << "?";
			else
				cout << setw(8) << board[x][y];
		}
		cout << endl;
	}
}

bool testWinner(int answer, int boardNum, int ansBoard[])
{
	
	if (answer == ansBoard[boardNum])
	{
		cout << "You are a number genius!!\n" << endl;
		return true;
	}
	else
	{
		cout << "I am sorry that was incorrect...\n" << endl;
		return false;
	}
}

void instructions()

{
	cout << "***********************************************************************\n";
	cout << "			MISSING NUMBERS GAME \n";
	cout << "\n			A fun brain game...\n";
	cout << "\n	Please enter a whole number to guess the missing number!\n";
	cout << "\n		Program developed by Steven Torres-Romero\n";
	cout << "***********************************************************************\n";
}
