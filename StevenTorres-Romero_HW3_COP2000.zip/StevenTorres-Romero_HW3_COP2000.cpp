// Steven Torres-Romero COP_2000 HW2 10/19/2018
// This program will show the membership fees for Rhonda�s Strikeforce Gym.
#include <iostream>
#include <iomanip>
using namespace std;

int main()

{

	int user_menu_input = 0;
	int year;
	const double GOLD = 1.01;
	const double SILVER = 1.02;
	const double BRONZE = 1.04;
	const double INITIAL_FEE = 1200.00;
	double cost;
	double rate;
	
	cout << setprecision(2) << fixed;

	do
	{
		cout << "	Welcome to Rhonda's Strikeforce Gym!!" << endl;
		cout << "x---------------------------------------------------x" << endl;
		cout << "	      Membership Fee Calculator" << endl;
		cout << "1. Gold" << endl;
		cout << "2. Silver" << endl;
		cout << "3. Bronze" << endl;
		cout << "4. Quit" << endl;
		cout << "Please enter a your membership level (1-3 Enter 4 to Quit) > ";
		cin >> user_menu_input;

		while (user_menu_input <= 0 || user_menu_input >= 5)
		{
			cout << "Invalid number has been inputted, please enter a number between 1 and 4. > ";
			cin >> user_menu_input;
		}


		switch (user_menu_input)
		{
		case 1:
			rate = GOLD;
			break;

		case 2:
			rate = SILVER;
			break;

		case 3:
			rate = BRONZE;
			break;
		}

		if (user_menu_input == 1 || user_menu_input == 2 || user_menu_input == 3)
		{
			for (year = 1, cost = rate * INITIAL_FEE; year <= 10; year++)
			{
				cout << "Year" << setw(5) << year << " $" << cost << endl;
				cost *= rate;
			}
			cout << endl;
		}
	} while (user_menu_input != 4);

	if (user_menu_input == 4)
		cout << "Thank you for using Rhonda's Fee Calculator!" << endl;





	return 0;

}