//Steven Torres-Romero 11/4/2018
//COP_2000 HW 4 Race Results

//This program will allow you to enter three racing time results and the racer�s first name. The
//program will determine which race time was the lowest, i.e. the winner.The program will also
//determine if there is a tie and output the name of the winner with their time, and/or the tied
//individuals

#include <iostream>
#include <string>

using namespace std;

int main()
{
	string racer1, racer2, racer3;
	double time1, time2, time3, raceaverage;

	cout << "********************************************************************************************\n";
	cout << "  Welcome to Race Results Program!\n";
	cout << "  You will be asked to enter the three racer's\n";
	cout << "  names and their associated race times.\n";
	cout << "\n  Please enter a real number for Race Time. <the Race Time Must be > 0>.\n\n";
	cout << "  Program developed by: Steven Torres-Romero\n";
	cout << "********************************************************************************************\n";

	cout << "\n Please enter the racer's first name > ";
	cin >> racer1;
	cout << "\n Please enter the racer's time > ";
	cin >> time1;
	while (time1 <= 0)
	{
		cout << "Invalid time input...time must be greater than 0> ";
		cin >> time1;
	}
	cout << "\n Please enter the racer's first name > ";
	cin >> racer2;
	cout << "\n Please enter the racer's time > ";
	cin >> time2;
	while (time2 <= 0)
	{
		cout << "Invalid time input...time must be greater than 0> ";
		cin >> time2;
	}
	cout << "\n Please enter the racer's first name > ";
	cin >> racer3;
	cout << "\n Please enter the racer's time > ";
	cin >> time3;
	while (time3 <= 0)
	{
		cout << "Invalid time input...time must be greater than 0> ";
		cin >> time3;
	}

	if (time1 < time2 && time1 < time3)
		{
		cout << "\nCongratulations	" << racer1 << "!!! You are the winner!!\n";
		cout << "***** Your winning time is: " << time1 << ". *****\n";
		}
	if (time2 < time1 && time2 < time3)
	{
		cout << "\nCongratulations	" << racer2 << "!!! You are the winner!!\n";
		cout << "***** Your winning time is: " << time2 << ". *****\n";
	}
	if (time3 <time1 && time3 < time2)
	{
		cout << "\nCongratulations	" << racer3 << "!!! You are the winner!!\n";
		cout << "***** Your winning time is: " << time3 << ". *****\n";
	}


	raceaverage = (time1 + time2 + time3) / 3;

	cout << "\n Overall Race Time Average: " << raceaverage << endl;

	cout << endl << "Press ENTER to exit...";
	system("PAUSE");
	return 0;
}
